# Setup guide — OMNHS Lost and Found

This is a standalone static website. It uses Firebase Authentication, Cloud Firestore, and Firebase Storage.

## 1. Create a Firebase project
1. Open https://console.firebase.google.com/ and choose **Add project**.
2. Give it a project name, for example `omnhs-lost-found`.
3. In Project Overview, click the Web icon (`</>`) to register a web app.
4. Copy the Firebase configuration object shown by Firebase.

## 2. Add your Firebase configuration
1. Open `app.js`.
2. Find `const firebaseConfig = { ... }` near the top.
3. Replace each `PASTE_...` value with the matching value from your Firebase web app.
4. Keep the quotation marks and property names exactly as shown.

## 3. Turn on email/password sign-in
1. In Firebase Console, open **Build → Authentication**.
2. Click **Get started**.
3. Open **Sign-in method**.
4. Enable **Email/Password** and save.

## 4. Create Firestore
1. Open **Build → Firestore Database**.
2. Click **Create database**.
3. Choose production mode and select a location close to your users.
4. Open the **Rules** tab.
5. Replace the rules with the contents of `firestore.rules`, then click **Publish**.

## 5. Create Firebase Storage
1. Open **Build → Storage** and click **Get started**.
2. Finish the setup.
3. Open the Storage **Rules** tab.
4. Replace the rules with the contents of `storage.rules`, then click **Publish**.

## 6. Set up the first admin account
For security, public sign-up only creates student or teacher accounts. Do not add an admin option to the public sign-up form.

1. Open the website and create an account using the email you will use as the school portal administrator.
2. In Firebase Console, open **Firestore Database → Data**.
3. Open the `users` collection.
4. Open the document whose ID matches the admin account's Firebase Authentication UID. You can find the UID in **Authentication → Users**.
5. Change the `role` field from `student` or `teacher` to the exact string `admin`.
6. Save. Log out and log back in to refresh the role in the website.

Only the authorized project owner/admin should assign admin access. Do not share your Firebase service-account credentials or passwords.

## 7. Test the website
1. Open `index.html` using a local web server (recommended), not by double-clicking the file. VS Code users can use the Live Server extension.
2. Create a student account.
3. Submit a sample lost-item report and a sample found-item report.
4. Log in as admin and approve the pending reports.
5. Log in as a different account and confirm the approved reports appear in Browse Items.
6. Test an item claim request.

## 8. Publish with GitHub Pages
1. Create a new GitHub repository, for example `omnhs-lost-and-found`.
2. Upload `index.html`, `styles.css`, `app.js`, `firestore.rules`, and `storage.rules`.
3. Open repository **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**.
5. Choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish your site.
7. In Firebase Authentication → Settings → Authorized domains, add your GitHub Pages hostname (for example `yourusername.github.io`) if it is not already listed.

## Important notes
- This starter site is designed for a school demonstration and should be reviewed by the school's authorized IT staff before real student use.
- The website stores account email addresses, report descriptions, and optional item photos. Publish a school-approved privacy notice and collect only information needed to return belongings.
- Do not post student ID numbers, home addresses, phone numbers, passwords, or sensitive details in public item reports.
- Public visitors can see approved reports and their photos. Do not upload photos that reveal personal data.
- The current interface supports submitting claims, but claim approval/management is not yet included in the admin dashboard. Arrange item handover through a designated school office/staff member.
- Firestore rules are a starting point. Test them with Firebase Emulator Suite and have a qualified administrator review them before deployment.
- Firebase configuration values for a web app are not service-account secrets, but access must still be protected by correct Firestore and Storage rules.
