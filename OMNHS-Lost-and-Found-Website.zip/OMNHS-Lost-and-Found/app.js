// Occidental Mindoro National High School Lost and Found
// 1) Paste your Firebase web-app configuration below.
// 2) Enable Email/Password Authentication, Firestore, and Storage in Firebase.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, updateProfile
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs,
  query, orderBy, where, updateDoc, deleteDoc, serverTimestamp, onSnapshot
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {
  getStorage, ref, uploadBytes, getDownloadURL
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};

const configReady = !Object.values(firebaseConfig).some(v => String(v).includes("PASTE_"));
let app, auth, db, storage;
if (configReady) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);
}

const $ = id => document.getElementById(id);
let currentUser = null, currentRole = "guest", reportType = "lost", authMode = "login", reports = [], unsubscribeReports = null;

function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  setTimeout(() => $("toast").classList.remove("show"), 3200);
}
function safeText(value="") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function dateText(value) {
  if (!value) return "Date not specified";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? safeText(value) : d.toLocaleDateString();
}
function openModal(id) { $(id).classList.remove("hidden"); }
function closeModal(id) { $(id).classList.add("hidden"); }
function setAuthMode(mode) {
  authMode = mode;
  document.querySelectorAll("[data-auth]").forEach(b => b.classList.toggle("active", b.dataset.auth === mode));
  $("authTitle").textContent = mode === "login" ? "Log in to your account" : "Create your account";
  $("authName").parentElement.classList.toggle("hidden", mode === "login");
  $("roleWrap").classList.toggle("hidden", mode === "login");
  $("authSubmit").textContent = mode === "login" ? "Log in" : "Create account";
  $("authPassword").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("authMessage").textContent = "";
}
function setReportType(type) {
  reportType = type;
  document.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("active", b.dataset.tab === type));
  $("dateLabel").textContent = type;
}
function showSetupMessage() {
  $("itemsGrid").innerHTML = '<div class="empty-state">Connect your Firebase project to load live reports. Follow the SETUP.md guide included with this website.</div>';
  ["statTotal","statLost","statFound","statReturned"].forEach(id => $(id).textContent = "0");
}
function renderStats() {
  $("statTotal").textContent = reports.length;
  $("statLost").textContent = reports.filter(x => x.type === "lost" && x.status !== "returned").length;
  $("statFound").textContent = reports.filter(x => x.type === "found" && x.status !== "returned").length;
  $("statReturned").textContent = reports.filter(x => x.status === "returned").length;
}
function renderItems() {
  const search = $("searchInput").value.trim().toLowerCase();
  const type = $("typeFilter").value, category = $("categoryFilter").value;
  const list = reports.filter(item => item.status === "approved" || item.status === "returned")
    .filter(item => type === "all" || item.type === type)
    .filter(item => category === "all" || item.category === category)
    .filter(item => [item.name,item.description,item.location,item.category].join(" ").toLowerCase().includes(search));
  $("itemsGrid").innerHTML = list.length ? list.map(item => `
    <article class="item-card">
      <div class="item-photo">${item.photoURL ? `<img src="${safeText(item.photoURL)}" alt="${safeText(item.name)}">` : "📦"}</div>
      <div class="item-body">
        <div class="item-top"><span class="pill ${item.status === "returned" ? "returned" : item.type}">${item.status === "returned" ? "Returned" : item.type}</span><span class="item-meta">${safeText(item.category || "Other")}</span></div>
        <h3>${safeText(item.name)}</h3>
        <p>${safeText(item.description || "No additional description provided.")}</p>
        <p>📍 ${safeText(item.location || "Location not specified")}</p>
        <div class="item-meta">${item.type === "lost" ? "Lost" : "Found"} on ${dateText(item.itemDate)}</div>
        ${currentUser && item.type === "found" && item.status !== "returned" && item.ownerUid !== currentUser.uid ? `<div class="item-actions"><button class="btn btn-primary" data-claim="${safeText(item.id)}">Request to claim</button></div>` : ""}
      </div>
    </article>`).join("") : '<div class="empty-state">No matching approved reports yet. Try another search or filter.</div>';
  document.querySelectorAll("[data-claim]").forEach(b => b.addEventListener("click", () => {
    $("claimItemId").value = b.dataset.claim; $("claimMessage").textContent = ""; $("claimDetails").value = ""; openModal("claimModal");
  }));
}
async function loadReports() {
  if (!db) return;
  try {
    const snap = await getDocs(query(collection(db,"reports"), orderBy("createdAt","desc")));
    reports = snap.docs.map(d => ({id:d.id,...d.data()}));
    renderStats(); renderItems(); renderMyReports();
    if (currentRole === "admin") renderAdminQueue();
  } catch (e) {
    console.error(e); $("itemsGrid").innerHTML = '<div class="empty-state">Could not load reports. Check your Firestore rules and setup.</div>';
  }
}
function renderMyReports() {
  if (!currentUser) return;
  const mine = reports.filter(r => r.ownerUid === currentUser.uid);
  $("myReports").innerHTML = mine.length ? mine.map(r => `<div class="my-report-row"><div><strong>${safeText(r.name)}</strong><div class="item-meta">${safeText(r.type)} · ${safeText(r.status || "pending")} · ${dateText(r.itemDate)}</div></div><span class="pill">${safeText(r.status || "pending")}</span></div>`).join("") : '<div class="empty-state">You have not submitted any reports yet.</div>';
}
function renderAdminQueue() {
  const pending = reports.filter(r => r.status === "pending");
  $("adminQueue").innerHTML = pending.length ? pending.map(r => `<div class="admin-row"><div><strong>${safeText(r.name)}</strong><div class="item-meta">${safeText(r.type)} · ${safeText(r.location)} · submitted by ${safeText(r.reporterName || "user")}</div></div><div class="item-actions"><button class="btn btn-primary" data-approve="${safeText(r.id)}">Approve</button><button class="btn btn-outline" data-reject="${safeText(r.id)}">Reject</button></div></div>`).join("") : '<div class="empty-state">There are no reports waiting for review.</div>';
  document.querySelectorAll("[data-approve]").forEach(b => b.addEventListener("click", () => moderateReport(b.dataset.approve,"approved")));
  document.querySelectorAll("[data-reject]").forEach(b => b.addEventListener("click", () => moderateReport(b.dataset.reject,"rejected")));
}
async function moderateReport(id,status) {
  try { await updateDoc(doc(db,"reports",id),{status,reviewedAt:serverTimestamp(),reviewedBy:currentUser.uid}); toast(`Report ${status}.`); await loadReports(); }
  catch(e){toast(e.message);}
}
async function uploadPhoto(file) {
  if (!file) return "";
  if (!["image/jpeg","image/png","image/webp"].includes(file.type)) throw new Error("Please upload a JPG, PNG, or WEBP image.");
  if (file.size > 5*1024*1024) throw new Error("Photo must be 5 MB or smaller.");
  const path = `report-photos/${currentUser.uid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const fileRef = ref(storage,path);
  await uploadBytes(fileRef,file,{contentType:file.type});
  return await getDownloadURL(fileRef);
}
async function submitReport(event) {
  event.preventDefault();
  if (!currentUser) { openModal("authModal"); toast("Please log in before submitting a report."); return; }
  const msg = $("reportMessage"); msg.textContent = "Submitting...";
  try {
    const photoURL = await uploadPhoto($("itemPhoto").files[0]);
    await addDoc(collection(db,"reports"),{
      type:reportType, name:$("itemName").value.trim(), category:$("itemCategory").value,
      itemDate:$("itemDate").value, location:$("itemLocation").value.trim(),
      description:$("itemDescription").value.trim(), photoURL,
      ownerUid:currentUser.uid, reporterName:currentUser.displayName || currentUser.email,
      status:"pending", createdAt:serverTimestamp()
    });
    $("reportForm").reset(); msg.textContent = "Your report was submitted for admin review.";
    toast("Report submitted successfully."); await loadReports();
  } catch(e) { console.error(e); msg.textContent = e.message || "Could not submit report."; }
}
async function submitClaim(event) {
  event.preventDefault();
  if (!currentUser) return;
  $("claimMessage").textContent = "Sending...";
  try {
    await addDoc(collection(db,"claims"),{
      reportId:$("claimItemId").value, claimantUid:currentUser.uid,
      claimantName:currentUser.displayName || currentUser.email,
      details:$("claimDetails").value.trim(), status:"pending", createdAt:serverTimestamp()
    });
    $("claimMessage").textContent = "Your claim request has been sent for review.";
    toast("Claim request sent.");
  } catch(e) { $("claimMessage").textContent = e.message; }
}
async function handleAuth(event) {
  event.preventDefault(); $("authMessage").textContent = "Please wait...";
  const email=$("authEmail").value.trim(), password=$("authPassword").value;
  try {
    if (authMode === "login") await signInWithEmailAndPassword(auth,email,password);
    else {
      const name=$("authName").value.trim();
      if (!name) throw new Error("Please enter your full name.");
      const credential=await createUserWithEmailAndPassword(auth,email,password);
      await updateProfile(credential.user,{displayName:name});
      await setDoc(doc(db,"users",credential.user.uid),{
        displayName:name,email,role:$("authRole").value,createdAt:serverTimestamp()
      });
    }
    closeModal("authModal"); $("authForm").reset(); toast("You are signed in.");
  } catch(e) { $("authMessage").textContent = friendlyAuthError(e); }
}
function friendlyAuthError(e) {
  const messages={"auth/invalid-credential":"Email or password is incorrect.","auth/email-already-in-use":"This email already has an account.","auth/weak-password":"Choose a password with at least 6 characters.","auth/invalid-email":"Please enter a valid email address.","auth/too-many-requests":"Too many attempts. Please try again later."};
  return messages[e.code] || e.message || "Authentication failed.";
}
async function setUser(user) {
  currentUser=user; currentRole="guest";
  if (user && db) {
    try { const profile=await getDoc(doc(db,"users",user.uid)); if(profile.exists()) currentRole=profile.data().role || "student"; }
    catch(e){console.error(e);}
  }
  $("loginNavBtn").classList.toggle("hidden",!!user);
  $("logoutBtn").classList.toggle("hidden",!user);
  $("account").classList.toggle("hidden",!user);
  $("adminPanel").classList.toggle("hidden",currentRole!=="admin");
  if(user) { $("account").scrollIntoView({behavior:"smooth",block:"start"}); }
  await loadReports();
}
function init() {
  $("loginNavBtn").addEventListener("click",()=>{setAuthMode("login");openModal("authModal");});
  $("closeAuth").addEventListener("click",()=>closeModal("authModal"));
  $("closeClaim").addEventListener("click",()=>closeModal("claimModal"));
  $("logoutBtn").addEventListener("click",async()=>{await signOut(auth);toast("You have logged out.");});
  document.querySelectorAll("[data-auth]").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.auth)));
  document.querySelectorAll("[data-tab]").forEach(b=>b.addEventListener("click",()=>setReportType(b.dataset.tab)));
  $("authForm").addEventListener("submit",handleAuth);
  $("reportForm").addEventListener("submit",submitReport);
  $("claimForm").addEventListener("submit",submitClaim);
  $("searchInput").addEventListener("input",renderItems);
  $("typeFilter").addEventListener("change",renderItems);
  $("categoryFilter").addEventListener("change",renderItems);
  $("refreshBtn").addEventListener("click",loadReports);
  if (!configReady) { showSetupMessage(); return; }
  onAuthStateChanged(auth,setUser);
}
init();
